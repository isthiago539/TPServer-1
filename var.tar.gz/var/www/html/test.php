<?php echo 'Prueba PHP'; ?>
